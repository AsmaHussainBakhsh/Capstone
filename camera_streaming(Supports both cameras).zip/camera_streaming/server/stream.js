const { spawn } = require('child_process');
const path = require('path');
const mongoose = require('mongoose');
const Recording = require('./models/Recording');
const fs = require('fs');

const RECORDINGS_DIR = path.join(__dirname, '..', 'recordings');

if (!fs.existsSync(RECORDINGS_DIR)) {
    fs.mkdirSync(RECORDINGS_DIR, { recursive: true });
}

mongoose.connect('mongodb+srv://60105868:12class34@cluster0.t2myy.mongodb.net/cameraDB?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    serverSelectionTimeoutMS: 30000,
    socketTimeoutMS: 45000
}).then(() => console.log('Stream.js: MongoDB connected'))
    .catch(err => {
        console.error('Stream.js: DB connection error:', err.message);
        process.exit(1);
    });

const RTSP_URL = 'rtsp://admin:YCIODP@192.168.137.159:554/H.264';
const FFMPEG_PATH = 'ffmpeg';
const HLS_OUTPUT = path.join(__dirname, '..', 'hls', 'playlist.m3u8');

function startFFmpeg() {
    // Clear the HLS playlist file before starting a new stream
    try {
        fs.unlinkSync(HLS_OUTPUT);
        console.log('HLS playlist file cleared.');
    } catch (err) {
        console.log('HLS playlist file does not exist or could not be deleted.');
    }

    const ffmpeg = spawn(FFMPEG_PATH, [
        '-loglevel', 'debug',
        '-rtsp_transport', 'tcp',
        '-i', RTSP_URL,

        // Input Options (Addressing Common RTSP Issues)
        '-analyzeduration', '2147483647', // Analyze the stream for a longer duration
        '-probesize', '2147483647',    // Probe the stream for a longer duration

        // Timestamp Correction and Frame Rate Handling
        '-fflags', '+genpts+igndts+discardcorrupt',
        '-copyts',
        '-start_at_zero',
        '-vsync', 'cfr', // Constant Frame Rate
        '-r', '25', // Output frame rate - adjust as needed

        // Video Encoding Options
        '-c:v', 'libx264',
        '-preset', 'veryfast',
        '-tune', 'zerolatency',
        '-profile:v', 'baseline',
        '-pix_fmt', 'yuv420p',

        // Audio Encoding Options
        '-c:a', 'aac',
        '-b:a', '128k', // Audio bitrate
        '-ar', '44100',  // Audio sample rate

        // HLS Output Options
        '-f', 'hls',
        '-hls_time', '2',
        '-hls_list_size', '5',
        '-hls_flags', 'delete_segments+append_list+omit_endlist',
        HLS_OUTPUT,

        // Recording Stream Options (adjust as needed)
        '-c:v', 'copy', // Copy video codec
        '-f', 'segment',
        '-segment_time', '30',
        '-reset_timestamps', '1',
        '-strftime', '1',
        path.join(RECORDINGS_DIR, 'recording_%Y-%m-%d_%H-%M-%S.mp4')
    ]);

    ffmpeg.stderr.on('data', (data) => {
        const message = data.toString();
        //if (message.includes('missed packets')) return; // REMOVE for debugging
        console.error(`FFmpeg: ${message}`);
    });

    ffmpeg.on('close', (code) => {
        console.log(`FFmpeg restarting (Code ${code})...`);
        setTimeout(startFFmpeg, 3000);
    });

    ffmpeg.on('error', (err) => {
        console.error(`FFmpeg Process Error: ${err.message}`);
    });
}

startFFmpeg();

setInterval(async () => {
    try {
        const recording = new Recording({
            title: `Recording_${new Date().toISOString()}`,
            filename: `recording_${Date.now()}.mp4`
        });
        await recording.save();
        console.log(`Recording saved: ${recording.title}`);
    } catch (err) {
        console.error('Recording save error:', err.message);
    }
}, 10000);


