const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
const WebSocket = require('ws');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use('/hls', express.static(path.join(__dirname, '..', 'hls')));
app.use('/recordings', express.static(path.join(__dirname, '..', 'recordings')));

const connectDB = async () => {
    try {
        await mongoose.connect('mongodb+srv://60105868:12class34@cluster0.t2myy.mongodb.net/cameraDB?retryWrites=true&w=majority', {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            serverSelectionTimeoutMS: 30000,
            socketTimeoutMS: 45000
        });
        console.log('MongoDB connected');
    } catch (err) {
        console.error('Database connection error:', err.message);
        setTimeout(connectDB, 5000);
    }
};

connectDB();

mongoose.connection.on('disconnected', () => {
    console.log('MongoDB disconnected');
    setTimeout(connectDB, 5000);
});

const Recording = require('./models/Recording');

app.get('/api/recordings', async (req, res) => {
    try {
        const recordings = await Recording.find().sort({ date: -1 }).limit(50);
        res.json(recordings);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

const PORT = process.env.PORT || 3000;
const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    console.log('New WebSocket connection');
    ws.on('error', (error) => {
        console.error('WebSocket error:', error);
    });
});

function broadcast(message) {
    wss.clients.forEach(client => {
        if (client.readyState === WebSocket.OPEN) {
            client.send(JSON.stringify(message));
        }
    });
}

Recording.watch().on('change', (change) => {
    if (change.operationType === 'insert') {
        broadcast(change.fullDocument);
    }
});



